import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
import global_planner

PATH = Path(
    '/home/tzm/Projects/2_Lab/carla_910/PythonAPI/vi_experiment_env/Town10HD_paths/')

data = np.load(PATH/'Town10HD_spawn_points.npy', allow_pickle=True)
path = np.load(PATH/'path_points_t10_68_114.npy', allow_pickle=True)

planner = global_planner.Planner(PATH/'path_points_t10_68_114.npy')

fig, ax = plt.subplots()
print(planner.path_pts.shape)
pt1 = 120
pt2 = 200


ax.plot(planner.path_pts[:,2], 'x')
ax.plot(pt1,planner.path_pts[pt1,2], 'rx')
ax.plot(pt2,planner.path_pts[pt2,2], 'rx')

fig2, ax2 = plt.subplots()
ax2.plot(planner.path_pts[:,0], planner.path_pts[:,1], '.-')
ax2.plot(planner.path_pts[pt1,0], planner.path_pts[pt1,1], 'rx')
ax2.plot(planner.path_pts[pt2,0], planner.path_pts[pt2,1], 'rx')



path_cut = path[120:, :]
path_cut[:,2] = path_cut[:,2] - path_cut[0,2]

np.save(PATH/'path_points_t10_68_114_demo.npy', path_cut)

# ax2.plot(path_cut[:,0], path_cut[:,1], 'g.-')


print(planner.path_pts[pt1,0], planner.path_pts[pt1,1])
print(planner.path_pts[pt2,0], planner.path_pts[pt2,1])

plt.show()
