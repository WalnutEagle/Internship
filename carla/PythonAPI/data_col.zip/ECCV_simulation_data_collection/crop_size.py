from skimage.io import imread, imshow, imsave
import cv2
chess=imread('/data2/kathakoli/carla/data/ECCV_img1/session_0/Town10HD/000/wk2/000000000019_BEV_bw_right.jpg')
cv2.imwrite('im_BEV.jpg',chess[250:600,575:925])