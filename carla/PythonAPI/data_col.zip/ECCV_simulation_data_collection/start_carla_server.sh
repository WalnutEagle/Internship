#!/bin/bash

cd /data2/kathakoli/carla/Unreal/CarlaUE4/Saved/StagedBuilds/LinuxNoEditor

#PORT_NUMBER=$1
CUDA_DEVICE=$0
display(){
MESA_GL_VERSION_OVERRIDE=4.5 MESA_GLSL_VERSION_OVERRIDE=450 CUDA_VISIBLE_DEVICES=0 ./CarlaUE4.sh -quality-level=Epic -world-port=$PORT_NUMBER -opengl
}

DISPLAY= ./CarlaUE4.sh -quality-level=Epic -world-port=$1 -opengl
#MESA_GL_VERSION_OVERRIDE=4.5 MESA_GLSL_VERSION_OVERRIDE=450 CUDA_VISIBLE_DEVICES=$CUDA_DEVICE DISPLAY= ./CarlaUE4.sh -quality-level=Epic -world-port=$PORT_NUMBER -opengl



