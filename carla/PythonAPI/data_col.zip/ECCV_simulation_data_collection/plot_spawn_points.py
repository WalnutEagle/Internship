import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
import global_planner

PATH = Path(
    '/home/tzm/Projects/2_Lab/carla_910/PythonAPI/vi_experiment_env/Town03_paths/')

data = np.load(PATH/'Town03_spawn_points.npy', allow_pickle=True)


plt.plot(data[:, 0], data[:, 1], '.')

for idx, d in enumerate(data):
    plt.text(d[0], d[1], str(idx), color="red", size=7)

plt.show()