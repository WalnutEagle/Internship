#!/bin/bash

python run_experiment.py --filter walker --path ./Town10HD_paths/path_points_t10_68_114_demo.npy --world Town10HD --start_id 68 --destination_id 114 --log_dir ./logs/ --timelimit 100

