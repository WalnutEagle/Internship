import os
import sys
import argparse
from shutil import copyfile, rmtree
from pathlib import Path
import numpy as np
import re
#
# Merge data collected in a batch according to their Map
# - Set all data to trainval
# - ignore problematic data
# - aggregate all data to a single set of data
# - rename data entry

TARGET_DIR = Path("/home/zanming/carla_dataset/vi_dataset/batch_5_merged/")


# TO_BE_MERGED = {"annotation":["_front", "_back", "_left", "_right","_wk1", "_wk2", "_meta"], 
#                 "depth":["_front", "_back", "_left", "_right","_wk1", "_wk2"], 
#                 "instance":["_front", "_back", "_left", "_right","_wk1", "_wk2"], 
#                 "rgb":["_front", "_back", "_left", "_right","_wk1", "_wk2"]}

TO_BE_MERGED = {"instruction":["_front", "_left", "_right"], 
                "rgb":["_front", "_left", "_right"]}

WK_FILES = ['wk1', 'wk2', 'wk3', 'wk4']

# TOWNS = ['Town01', 'Town02', 'Town03', 'Town05', 'Town10HD']
TOWNS = ['Town05'] # train town only
IGNORE = ['record.md']


#================================================
# Setting for batch_2022_03_01
#------------------------------------------------
CORSE_FILTER = []

FILTER = {}


def rename_file(old_path, new_path):
    os.rename(str(old_path), str(new_path))
    # print("old name: ", old_path)
    # print("new name: ", new_path)
    return


def copy_to(old_path, new_path):
    copyfile(old_path, new_path)
    # print("from: ", old_path)
    # print("to: ", new_path)
    return

def merge_data(root, merge_dirs, output_dir):
    # merge foledrs under data_dir with same folder name
    # reindex files (keep consistency)
    merge_dirs.sort()
    img_idx = 0 # image_number_counter
    need_filter = False
    for d in merge_dirs: # for each episode
        mem = 0
        if d in FILTER.keys():
            # print('Filtering: ', d)
            need_filter = True
        meta_dir = root/d/'meta'
        meta_files = os.listdir(meta_dir)
        meta_files = sorted(meta_files, key= lambda x: int(x.split("_")[0]))
        if not os.path.exists(str(output_dir/"meta")):
            (output_dir/"meta").mkdir(parents=True, exist_ok=True)
        print("Merging: ", d)
        for wkf in WK_FILES:
            wk_dir = root/d/wkf
            print("- processing: ", wk_dir, ", cout: ", img_idx)
            for f, subtype in TO_BE_MERGED.items(): # process instruction/ rgb
                subtype_idx = img_idx
                _dir = wk_dir/f
                if not os.path.exists(str(output_dir/f)):
                    (output_dir/f).mkdir(parents=True, exist_ok=True)

                for s in subtype:
                    file_list = [_ for _ in os.listdir(_dir) if re.match('[0-9]+%s.*' % s, _)]
                    if len(file_list) == 0: # skip if empty
                        continue
                    file_list = sorted(file_list, key= lambda x: int(x.split("_")[0]))
                    ext = file_list[0].split('.')[-1]
                    for _file in file_list:
                        if f == "rgb": # copy meta file for each image instruction pair
                            meta_path = meta_dir/meta_files[int(_file.split("_")[0])] # corresponding meta file
                            new_meta_path = output_dir/'meta'/("%012d_meta.npy"%(subtype_idx))
                            copy_to(meta_path, new_meta_path)
                        file_path = _dir/_file
                        new_path = output_dir/f/("%012d.%s"%(subtype_idx, ext))
                        copy_to(file_path, new_path)
                        subtype_idx += 1
            img_idx = subtype_idx



def main(args):
    batch_dir = Path(args.dir)
    target_dir = batch_dir/'..'/(batch_dir.name+'_merged')
    print('target: ', target_dir)
    files = os.listdir(batch_dir)
    files.sort()
    print("Executing on : ", files)
    for town in TOWNS:
        merge_dirs = []
        for date_f in files:
            if date_f in IGNORE:
                continue
            session_dir = os.listdir(str(batch_dir/date_f))
            session_dir.sort()
            for sess_f in session_dir:
                if date_f+'/'+sess_f+'/'+town in CORSE_FILTER:
                    print("skipped: ", date_f+'/'+sess_f+'/'+town)
                    continue
                if os.path.exists(str(batch_dir/date_f/sess_f/town)):
                    episode_dir = os.listdir(str(batch_dir/date_f/sess_f/town))
                    episode_dir.sort()
                    merge_dirs += [date_f+'/'+sess_f+'/'+town+'/'+epsd_f for epsd_f in episode_dir]
        # merge_dirs = ['2022_02_05_01_53_04/session_0/Town01/000']
        print('merging: ', merge_dirs)
        merge_data(batch_dir, merge_dirs, target_dir/town)
    return


if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument("--dir", default=None,
                        required=True, help="Batch directory")
    args = parser.parse_args()
    main(args)
    # source = Path("/data2/zanming/data/xworld_9_13/batch_2022_01_20/2022_01_10_12_20_00/session_2/Town10HD")
    # target = Path('/data2/zanming/data/TESTING')
    # merge_data(source, target)
