#!/bin/bash

#!/bin/bash

python collect_data_points.py --filter walker --world Town03 --start_id 68 --destination_id 114 --save_dir ./
