#!/bin/bash

python run_gt_experiment.py --filter walker --world Town05 --path ./Town05_paths/path_points_t05_7_100_1.npy \
                            --start_id 7 --destination_id 100 --save_dir /data2/kathakoli/carla/PythonAPI/ECCV_simulation_data_collection/image_captured \
                            --log_dir /data2/kathakoli/carla/PythonAPI/ECCV_simulation_data_collection/logs/
