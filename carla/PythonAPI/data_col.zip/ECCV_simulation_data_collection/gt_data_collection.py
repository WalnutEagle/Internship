import sys
import os
import gc

from pathlib import Path
import argparse
import traceback

import numpy as np
import tqdm
import carla
import cv2
import pandas as pd

from PIL import Image

import random
# import pygame
from carla import TrafficLightState as tls

try:
    import queue
except ImportError:
    import Queue as queue

import time
import signal

from pycocotools import mask
from skimage import measure


import freemap_extraction as fme
from freemap import Freemap
import instruction_generation as ig
import global_planner
import util

from CarlaSyncMode import CarlaSyncMode

from scipy import ndimage
import matplotlib.pyplot as plt

def spawn_camera(world, vehicle, _type, w, h, fov, x, y, z, pitch, yaw):
    if _type == 'rgb':
        camera_bp = world.get_blueprint_library().find('sensor.camera.rgb')
    elif _type == 'semantic_segmentation':
        camera_bp = world.get_blueprint_library().find(
            'sensor.camera.semantic_segmentation')
    elif _type == 'depth':
        camera_bp = world.get_blueprint_library().find('sensor.camera.depth')

    camera_bp.set_attribute('image_size_x', str(w))
    camera_bp.set_attribute('image_size_y', str(h))
    camera_bp.set_attribute('fov', str(fov))
    _camera = world.spawn_actor(
        camera_bp,
        carla.Transform(carla.Location(x=x, y=y, z=z),
                        carla.Rotation(pitch=pitch, yaw=yaw)),
        attach_to=vehicle)

    view_width = w
    view_height = h
    view_fov = fov
    if _type == 'rgb':
        calibration = np.identity(3)
        calibration[0, 2] = view_width / 2.0
        calibration[1, 2] = view_height / 2.0
        calibration[0, 0] = calibration[1, 1] = view_width / \
            (2.0 * np.tan(view_fov * np.pi / 360.0))
        _camera.calibration = calibration

    return _camera


def spawn_cameras(world, actor, width, height, fov):
    cameras = {}
    # eye-level camera
    x_forward_eyelevel = 0.4
    cam_height_eyelevel = 0.8 #random.uniform(0.5,1.0)
    cameras['rgb'] = spawn_camera(world, actor, 'rgb', width, height, fov,
                                           x_forward_eyelevel, 0.0, cam_height_eyelevel, 0.0, 0.0)
    cameras['semseg'] = spawn_camera(world, actor, 'semantic_segmentation', width, height,
                                              fov, x_forward_eyelevel, 0.0, cam_height_eyelevel, 0.0, 0.0)
    cameras['depth'] = spawn_camera(world, actor, 'depth', width, height, fov,
                                             x_forward_eyelevel, 0.0, cam_height_eyelevel, 0.0, 0.0)

    cameras['rgb_right'] = spawn_camera(world, actor, 'rgb', width, height, fov,
                                           x_forward_eyelevel, 0.0, cam_height_eyelevel, 0.0, 45.0)

    cameras['semseg_right'] = spawn_camera(world, actor, 'semantic_segmentation', width, height,
                                              fov, x_forward_eyelevel, 0.0, cam_height_eyelevel, 0.0, 45.0)
    cameras['depth_right'] = spawn_camera(world, actor, 'depth', width, height, fov,
                                             x_forward_eyelevel, 0.0, cam_height_eyelevel, 0.0, 45.0)

    cameras['rgb_left'] = spawn_camera(world, actor, 'rgb', width, height, fov,
                                           x_forward_eyelevel, 0.0, cam_height_eyelevel, 0.0, -45.0)
    cameras['semseg_left'] = spawn_camera(world, actor, 'semantic_segmentation', width, height,
                                              fov, x_forward_eyelevel, 0.0, cam_height_eyelevel, 0.0, -45.0)
    cameras['depth_left'] = spawn_camera(world, actor, 'depth', width, height, fov,
                                             x_forward_eyelevel, 0.0, cam_height_eyelevel, 0.0, -45.0)
    return cameras


def preprocess_imgs(img, semantics_img):
    start = (750, 750)
    viewable_mask = np.tril(np.ones(img.shape)) * \
    np.flip(np.tril(np.ones(img.shape)), axis=1) # assume 90 fov
    img = img * viewable_mask
    semantics_img[start[1] - 25 : start[1] + 25, start[0] - 25 : start[0] + 25] = 0
    range_mask = np.zeros(img.shape)
    range_mask[start[1] - 25 : start[1] + 25, start[0] - 25 : start[0] + 25] = 1
    img[(viewable_mask * range_mask) > 0] = 1
    return img, semantics_img

def join_sentences(sentence_pieces):
    if len(sentence_pieces) > 0:
        sentence = [sentence_pieces[0]]
        for s in sentence_pieces[1:]:
            conn = random.choice(ig.InstructionGeneration.CONNECTIVE_WORDS)
            sentence += [conn + s]
        return ''.join(sentence)
    else:
        return ''

def generate_instruction_random(local_planner, imgs, unfilled_imgs, semantics_imgs, min_s=1, max_s=5, m_per_pixel=0.02, counter = 0, limit = 2):
    start = (750, 750)
    next_goal = ig.choose_endpoint(unfilled_imgs['front'], start, int(min_s/m_per_pixel),int(max_s/m_per_pixel))
    if counter > limit:
        print('Error: exceeds limit')
        # fig1, ax1 = plt.subplots()
        # vis_img = img.copy()
        # ax1.imshow(vis_img, origin='lower') # origin at left-bottom corner
        # plt.show()
        # print("++++++++++")
        null_inst = {'goal': [], 'instruction': [], 'instruction_cluster': [], 'instruction_sentence': '', 'descriptions': [], 'description_cluster': []}
        return null_inst, null_inst, null_inst
    if (next_goal == None) or (imgs['front'][next_goal[1], next_goal[0]] != 1):
        if next_goal == None:
            # fig2, ax2 = plt.subplots()
            # vis_img = semantics_img.copy()
            # ax2.imshow(vis_img, origin='lower') # origin at left-bottom corner
            # plt.show()
            print("Error: goal is None")
        else:
            print("non-free point selected")
        return generate_instruction_random(local_planner,imgs, unfilled_imgs, semantics_imgs, min_s = 1, max_s=5, counter = counter+1, limit = limit)

    goals_in_meters = (np.array(next_goal) - start)*m_per_pixel
    # get goal in left and right coordinate frame
    mat_faceleft = fme.get_rotation_mat_z(45)
    mat_faceright = fme.get_rotation_mat_z(-45)
    goal_in_meters_faceleft = mat_faceleft @ [goals_in_meters[0], goals_in_meters[1], 0]
    goal_in_meters_faceright = mat_faceright @ [goals_in_meters[0], goals_in_meters[1], 0]
    # print('GOAL in pixel:', next_goal)
    # print('GOAL in meters: ', goals_in_meters)
    # print('location: ', x, y, yaw)
    # print('next_goal: ', next_goal, (goal_x, goal_y), np.linalg.norm([goal_x - x, goal_y - y]), np.linalg.norm([(next_goal[0] - 750)*0.02, (next_goal[1] - 750)*0.02]))
    set_timelimit(2)
    result = None
    try:
        result = local_planner.astar(start, next_goal)
    except Exception:
        pass
    set_timelimit(0)
    # print('before', start, next_goal)
    if result != None:
        path = np.array(list(result))
        ins = ig.InstructionGeneration((0, 0, 0), path.copy(), semantics_imgs['front'], m_per_pixel)
        fl_ins = ig.InstructionGeneration((0, 0, np.pi/4), path.copy(), semantics_imgs['left'], m_per_pixel) # left view instruction
        fr_ins = ig.InstructionGeneration((0, 0, -np.pi/4), path.copy(), semantics_imgs['right'], m_per_pixel) # right view instruction
        instruction, instruction_cluster, poc = ins.get_instructions()
        description, description_cluster, des_poc = ins.get_description(poc)
        fl_instruction, fl_instruction_cluster, fl_poc = fl_ins.get_instructions()
        fl_description, fl_description_cluster, fl_des_poc = fl_ins.get_description(poc)
        fr_instruction, fr_instruction_cluster, fr_poc = fr_ins.get_instructions()
        fr_description, fr_description_cluster, fr_des_poc = fr_ins.get_description(poc)

        # generate goals for different coord-frame
        goals = (path[poc] - start)*m_per_pixel # goal in front facing camera coord-frame
        padded_goals = np.c_[goals, np.zeros(len(goals))] # n*[]
        goals_faceleft = (mat_faceleft@padded_goals.T).T
        goals_faceright = (mat_faceright@padded_goals.T).T

        # print(len(path), poc)
        # print("Instructions: ", instruction)
        # print("Instruction Cluster: ", instruction_cluster)
        # print("Description: ", description)
        # print("Description Cluster: ", description_cluster)
        # ax.plot(fm.points[:,0], fm.points[:,1], color=tuple(np.array([Tags.Colors[tag] for tag in fm.tags])/255))
        # plt.show()
        # print("Goal points: ", goal_pts)
        inst_facefront = {'goal': goals[1:len(instruction)+1, :2], 'instruction': instruction, 'instruction_cluster': instruction_cluster,
                'instruction_sentence':join_sentences(instruction), 'descriptions': description, 'description_cluster': description_cluster}
        inst_faceleft = {'goal': goals_faceleft[1:len(fl_instruction)+1, :2], 'instruction': fl_instruction, 'instruction_cluster': fl_instruction_cluster,
                'instruction_sentence':join_sentences(fl_instruction), 'descriptions': fl_description, 'description_cluster': fl_description_cluster}
        inst_faceright = {'goal': goals_faceright[1:len(fr_instruction)+1, :2], 'instruction': fr_instruction, 'instruction_cluster': fr_instruction_cluster,
                'instruction_sentence':join_sentences(fr_instruction), 'descriptions': fr_description, 'description_cluster': fr_description_cluster}
        return inst_facefront, inst_faceleft, inst_faceright
    else: 
        return generate_instruction_random(local_planner,imgs, unfilled_imgs, semantics_imgs, min_s = 1, max_s=5, counter = counter+1, limit = limit)


def generate_instruction_faceleft_random(local_planner, imgs, unfilled_imgs, semantics_imgs, min_s=1, max_s=5, m_per_pixel=0.02, counter = 0, limit = 2):
    start = (750, 750)    
    next_goal = ig.choose_endpoint(unfilled_imgs['left'], start, int(min_s/m_per_pixel),int(max_s/m_per_pixel))
    if counter > limit:
        print('Error: exceeds limit')
        null_inst =  {'goal': [], 'instruction': [], 'instruction_cluster': [], 'instruction_sentence': '', 'descriptions': [], 'description_cluster': []}
        return null_inst, null_inst, null_inst

    if (next_goal == None) or (imgs['left'][next_goal[1], next_goal[0]] != 1):
        if next_goal == None:
            print("Error: goal is None")
        else:
            print("non-free point selected")
        return generate_instruction_faceleft_random(local_planner, imgs, unfilled_imgs, semantics_imgs, min_s = 1, max_s=5, counter = counter+1, limit = limit)

    goals_in_meters = (np.array(next_goal) - start)*m_per_pixel
    # get goal in left and right coordinate frame
    mat_facefront = fme.get_rotation_mat_z(-45)
    mat_faceright = fme.get_rotation_mat_z(-90)
    goal_in_meters_facefront = mat_facefront @ [goals_in_meters[0], goals_in_meters[1], 0]
    goal_in_meters_faceright = mat_faceright @ [goals_in_meters[0], goals_in_meters[1], 0]

    # print('location: ', x, y, yaw)
    # print('next_goal: ', next_goal, (goal_x, goal_y), np.linalg.norm([goal_x - x, goal_y - y]), np.linalg.norm([(next_goal[0] - 750)*0.02, (next_goal[1] - 750)*0.02]))
    set_timelimit(2)
    result = None
    try:
        result = local_planner.astar(start, next_goal)
    except Exception:
        pass
    set_timelimit(0)
    # print('before', start, next_goal)
    if result != None:
        path = np.array(list(result))
        ins = ig.InstructionGeneration((0, 0, 0), path.copy(), semantics_imgs['left'], m_per_pixel)
        ff_ins = ig.InstructionGeneration((0, 0, -np.pi/4), path.copy(), semantics_imgs['front'], m_per_pixel) # front view instruction
        fr_ins = ig.InstructionGeneration((0, 0, -np.pi/2), path.copy(), semantics_imgs['right'], m_per_pixel) # right view instruction
        instruction, instruction_cluster, poc = ins.get_instructions()
        description, description_cluster, des_poc = ins.get_description(poc)
        ff_instruction, ff_instruction_cluster, ff_poc = ff_ins.get_instructions()
        ff_description, ff_description_cluster, ff_des_poc = ff_ins.get_description(poc)
        fr_instruction, fr_instruction_cluster, fr_poc = fr_ins.get_instructions()
        fr_description, fr_description_cluster, fr_des_poc = fr_ins.get_description(poc)

        # generate goals for different coord-frame
        goals = (path[poc] - start)*m_per_pixel # goal in left facing camera coord-frame
        padded_goals = np.c_[goals, np.zeros(len(goals))] # n*[]
        goals_facefront = (mat_facefront@padded_goals.T).T
        goals_faceright = (mat_faceright@padded_goals.T).T

        # print(len(path), poc)
        # print("Instructions: ", instruction)
        # print("Instruction Cluster: ", instruction_cluster)
        # print("Description: ", description)
        # print("Description Cluster: ", description_cluster)
        # ax.plot(fm.points[:,0], fm.points[:,1], color=tuple(np.array([Tags.Colors[tag] for tag in fm.tags])/255))
        # plt.show()
        # print("Goal points: ", goal_pts)
        inst_facefront = {'goal': goals_facefront[1:len(ff_instruction)+1, :2], 'instruction': ff_instruction, 'instruction_cluster': ff_instruction_cluster,
                'instruction_sentence':join_sentences(ff_instruction), 'descriptions': ff_description, 'description_cluster': ff_description_cluster}
        inst_faceleft = {'goal': goals[1:len(instruction)+1, :2], 'instruction': instruction, 'instruction_cluster': instruction_cluster,
                'instruction_sentence':join_sentences(instruction), 'descriptions': description, 'description_cluster': description_cluster}
        inst_faceright = {'goal': goals_faceright[1:len(fr_instruction)+1, :2], 'instruction': fr_instruction, 'instruction_cluster': fr_instruction_cluster,
                'instruction_sentence':join_sentences(fr_instruction), 'descriptions': fr_description, 'description_cluster': fr_description_cluster}
        return inst_facefront, inst_faceleft, inst_faceright
    else: 
        return generate_instruction_faceleft_random(local_planner,imgs, unfilled_imgs, semantics_imgs, min_s = 1, max_s=5, counter = counter+1, limit = limit)


def generate_instruction_faceright_random(local_planner, imgs, unfilled_imgs, semantics_imgs, min_s=1, max_s=5, m_per_pixel=0.02, counter = 0, limit = 2):
    start = (750, 750)    
    # ==========
    # preprocess image
    # ----------
    viewable_mask = np.tril(np.ones(imgs['right'].shape)) * \
        np.flip(np.tril(np.ones(imgs['right'].shape)), axis=1) # assume 90 fov
    imgs['right'] = imgs['right'] * viewable_mask
    semantics_imgs['right'][start[1] - 25 : start[1] + 25, start[0] - 25 : start[0] + 25] = 0
    # ----------
    next_goal = ig.choose_endpoint(unfilled_imgs['right'], start, int(min_s/m_per_pixel),int(max_s/m_per_pixel))
    if counter > limit:
        print('Error: exceeds limit or No goal selected')
        null_inst =  {'goal': [], 'instruction': [], 'instruction_cluster': [], 'instruction_sentence': '', 'descriptions': [], 'description_cluster': []}
        return null_inst, null_inst, null_inst

    if (next_goal == None) or (imgs['right'][next_goal[1], next_goal[0]] != 1):
        if next_goal == None:
            print("Error: goal is None")
        else:
            print("non-free point selected")
        return generate_instruction_faceright_random(local_planner, imgs, unfilled_imgs, semantics_imgs, min_s = 1, max_s=5, counter = counter+1, limit = limit)


    goals_in_meters = (np.array(next_goal) - start)*m_per_pixel
    # get goal in left and right coordinate frame
    mat_facefront = fme.get_rotation_mat_z(45)
    mat_faceleft = fme.get_rotation_mat_z(90)
    goal_in_meters_facefront = mat_facefront @ [goals_in_meters[0], goals_in_meters[1], 0]
    goal_in_meters_faceleft = mat_faceleft @ [goals_in_meters[0], goals_in_meters[1], 0]
    # print('location: ', x, y, yaw)
    # print('next_goal: ', next_goal, (goal_x, goal_y), np.linalg.norm([goal_x - x, goal_y - y]), np.linalg.norm([(next_goal[0] - 750)*0.02, (next_goal[1] - 750)*0.02]))
    set_timelimit(2)
    result = None
    try:
        result = local_planner.astar(start, next_goal)
    except Exception:
        pass
    set_timelimit(0)
    # print('before', start, next_goal)
    if result != None:
        path = np.array(list(result))
        ins = ig.InstructionGeneration((0, 0, 0), path.copy(), semantics_imgs['right'], m_per_pixel)
        ff_ins = ig.InstructionGeneration((0, 0, np.pi/4), path.copy(), semantics_imgs['front'], m_per_pixel) # front view instruction
        fl_ins = ig.InstructionGeneration((0, 0, np.pi/2), path.copy(), semantics_imgs['left'], m_per_pixel) # left view instruction
        instruction, instruction_cluster, poc = ins.get_instructions()
        description, description_cluster, des_poc = ins.get_description(poc)
        ff_instruction, ff_instruction_cluster, ff_poc = ff_ins.get_instructions()
        ff_description, ff_description_cluster, ff_des_poc = ff_ins.get_description(poc)
        fl_instruction, fl_instruction_cluster, fl_poc = fl_ins.get_instructions()
        fl_description, fl_description_cluster, fl_des_poc = fl_ins.get_description(poc)

        # generate goals for different coord-frame
        goals = (path[poc] - start)*m_per_pixel # goal in right facing camera coord-frame
        padded_goals = np.c_[goals, np.zeros(len(goals))] # n*[]
        goals_facefront = (mat_facefront@padded_goals.T).T
        goals_faceleft = (mat_faceleft@padded_goals.T).T

        # print(len(path), poc)
        # print("Instructions: ", instruction)
        # print("Instruction Cluster: ", instruction_cluster)
        # print("Description: ", description)
        # print("Description Cluster: ", description_cluster)
        # ax.plot(fm.points[:,0], fm.points[:,1], color=tuple(np.array([Tags.Colors[tag] for tag in fm.tags])/255))
        # plt.show()
        # print("Goal points: ", goal_pts)
        inst_facefront = {'goal': goals_facefront[1:len(ff_instruction)+1, :2], 'instruction': ff_instruction, 'instruction_cluster': ff_instruction_cluster,
                'instruction_sentence': join_sentences(ff_instruction), 'descriptions': ff_description, 'description_cluster': ff_description_cluster}
        inst_faceleft = {'goal': goals_faceleft[1:len(fl_instruction)+1, :2], 'instruction': fl_instruction, 'instruction_cluster': fl_instruction_cluster,
                'instruction_sentence': join_sentences(fl_instruction), 'descriptions': fl_description, 'description_cluster': fl_description_cluster}
        inst_faceright = {'goal': goals[1:len(instruction)+1, :2], 'instruction': instruction, 'instruction_cluster': instruction_cluster,
                'instruction_sentence': join_sentences(instruction), 'descriptions': description, 'description_cluster': description_cluster}
        return inst_facefront, inst_faceleft, inst_faceright
    else: 
        return generate_instruction_faceright_random(local_planner,imgs, unfilled_imgs, semantics_imgs, min_s = 1, max_s=5, counter = counter+1, limit = limit)



def generate_multiple_random_instructions(n, local_planner, imgs, unfilled_imgs, semantics_imgs, min_s=1, max_s=5, m_per_pixel=0.02, counter = 0, limit = 5):
    # goal in front view
    instruction_front_aggregate = []
    instruction_right_aggregate = []
    instruction_left_aggregate = []

    local_planner.update(imgs['front'])
    print("front view instruction")
    for i in range(n):
        inst_facefront, inst_faceleft, inst_faceright = generate_instruction_random(local_planner, imgs.copy(), unfilled_imgs.copy(), semantics_imgs.copy(), min_s, max_s, m_per_pixel, counter, limit)
        instruction_front_aggregate.append(inst_facefront)
        instruction_left_aggregate.append(inst_faceleft)
        instruction_right_aggregate.append(inst_faceright)
    # goal in left facing view
    local_planner.update(imgs['left'])
    print("left view instruction")
    for i in range(n):
        inst_facefront, inst_faceleft, inst_faceright = generate_instruction_faceleft_random(local_planner, imgs.copy(), unfilled_imgs.copy(), semantics_imgs.copy(), min_s, max_s, m_per_pixel, counter, limit)
        instruction_front_aggregate.append(inst_facefront)
        instruction_left_aggregate.append(inst_faceleft)
        instruction_right_aggregate.append(inst_faceright)

    # goal in right facing view
    local_planner.update(imgs['right'])
    print("right view instruction")
    for i in range(n):
        inst_facefront, inst_faceleft, inst_faceright = generate_instruction_faceright_random(local_planner, imgs.copy(), unfilled_imgs.copy(), semantics_imgs.copy(), min_s, max_s, m_per_pixel, counter, limit)
        instruction_front_aggregate.append(inst_facefront)
        instruction_left_aggregate.append(inst_faceleft)
        instruction_right_aggregate.append(inst_faceright)
    return instruction_front_aggregate, instruction_left_aggregate, instruction_right_aggregate



def signal_handler(signum, frame):
    raise Exception("Timed out!")

def set_timelimit(seconds):
    signal.signal(signal.SIGALRM, signal_handler)
    signal.alarm(seconds)
    return



# ------------------------------------------------------------------------
# Config
# ------------------------------------------------------------------------
percent_disabled = 0.0

# camera parameters
width = 1920 #1600
height = 1080 #900
fov = 90
focal = width / (2.0 * np.tan(fov * np.pi / 360.0))

inst_per_image = 5

# weather control

WEATHERS = {'train': [carla.WeatherParameters.ClearNoon, carla.WeatherParameters.ClearSunset,  carla.WeatherParameters.WetNoon] , \
            'test': [carla.WeatherParameters.WetCloudyNoon, carla.WeatherParameters.HardRainNoon, carla.WeatherParameters.HardRainSunset]}



WEATHERS_DICT = {
    carla.WeatherParameters.ClearNoon: 'ClearNoon',
    carla.WeatherParameters.WetNoon: 'WetNoon',
    carla.WeatherParameters.WetCloudyNoon: 'WetCloudyNoon',
    carla.WeatherParameters.HardRainNoon: 'HardRainNoon',
    carla.WeatherParameters.ClearSunset: 'ClearSunset',
    carla.WeatherParameters.SoftRainSunset: 'SoftRainSunset',
    carla.WeatherParameters.HardRainSunset: 'HardRainSunset',
}

TOWN_SPLIT_MAP = {'Town05': 'train', 'Town10HD': 'train'}

# --------------------------------------------------------------------------
def convert(array):
    # Define your color list
    narray=np.array(array)
    colors = [
        (0, 0, 0), (70, 70, 70), (100, 40, 40), (55, 90, 80), (220, 20, 60),
        (153, 153, 153), (157, 234, 50), (128, 64, 128), (244, 35, 232),
        (107, 142, 35), (0, 0, 142), (102, 102, 156), (220, 220, 0),
        (70, 130, 180), (81, 0, 81), (150, 100, 100), (230, 150, 140),
        (180, 165, 180), (250, 170, 30), (110, 190, 160), (170, 120, 50),
        (45, 60, 150), (145, 170, 100)
    ]

    Darray = narray.astype(int)

    # Create a colored version of your 2D array
    colored_array = np.array([[colors[value] for value in row] for row in Darray])
    final_array=np.flipud(colored_array)
    return final_array

def check_affordance(arr):
    #print("Hello")
    arr1=np.zeros(4)
    if np.any(arr[425:600,575:750]==2):
        #print(arr[425:600,575:750])
        arr1[0]=1
    if np.any(arr[425:600,750:925]==2):
        #print(arr[425:600,750:925])
        arr1[1]=1
    if np.any(arr[250:425,575:750]==2):
        #print(arr[250:425,575:750])
        arr1[2]=1
    if np.any(arr[250:425,750:925]==2):
        #print(arr[250:425,750:925])
        arr1[3]=1
    return arr1
    

def main(args):
    if args.session_id != None:
        session_name = 'session_{}'.format(args.session_id)
        print('Running Sessions: {}'.format(session_name))
    else:
        session_name=''

    port = args.carla_port
    tm_port = args.tm_port #3000

    gap = args.frame_gap
    max_frame = args.max_frame


    SAVE_PATH = Path('/data2/kathakoli/carla/data/ECCV_img{}'.format(args.time_str))
    SAVE_PATH = SAVE_PATH/session_name

    if not os.path.exists(str(SAVE_PATH)):
        SAVE_PATH.mkdir(parents=True,exist_ok=True)

    town = args.town
    assert town in ['Town01', 'Town02', 'Town03', 'Town05', 'Town10HD'], "Invalid Town name"
    number_of_vehicles = args.vehicles
    number_of_walkers = args.walkers
    epochs = args.epochs
    split = TOWN_SPLIT_MAP[town]

    _SAVE_PATH = SAVE_PATH / town
    if not os.path.exists(str(_SAVE_PATH)):
        _SAVE_PATH.mkdir()

    tag_set = list(fme.Tags.Hash2.values())
    path_finder = ig.PathFinder()


    for eps in range(epochs):
        print("Running Epoch: ", eps)
        if os.path.exists(str(_SAVE_PATH / ('%03d' % eps))):
            print('%d Existed! Skip!' % eps)
            continue

        # create saving folders
        save_dir = _SAVE_PATH / ('%03d' % eps)


        wk_list = ['wk1', 'wk2', 'wk3', 'wk4']
        wk_path = []

        for wk in wk_list:
            wk_save_dir = save_dir / wk
            if not os.path.exists(str((wk_save_dir))):
                (wk_save_dir).mkdir(parents=True, exist_ok=True)
            # if not os.path.exists(str((wk_save_dir / 'depth'))):
            #     (wk_save_dir / 'depth').mkdir(parents=True, exist_ok=True)
            # if not os.path.exists(str((wk_save_dir / 'semantic'))):
            #     (wk_save_dir / 'semantic').mkdir(parents=True, exist_ok=True)
            # if not os.path.exists(str((wk_save_dir / 'instruction'))):
            #     (wk_save_dir / 'instruction').mkdir(parents=True, exist_ok=True)
            
            wk_path.append(wk_save_dir)
            # wk_depth_path.append(wk_save_dir / 'depth')
            # wk_semantic_path.append(wk_save_dir / 'semantic')
            # wk_semantic_coloured_path.append(wk_save_dir / 'instruction')

        if not os.path.exists(str((save_dir / 'meta'))):
            (save_dir / 'meta').mkdir(parents=True, exist_ok=True)
        # set random seed for each epoch
        tm_seed = np.random.randint(0, 2022)
        seedw = np.random.randint(0, 2022)
        np.random.seed(seedw)
        random.seed(seedw)

        actor_list = []
        # pygame.init()
        # clock = pygame.time.Clock()
        client = carla.Client('localhost', port)
        client.set_timeout(200000.0)
        world = client.load_world(town)

        try:

            # config traffic manager
            print("Setting up traffic_manager")

            traffic_manager = util.get_traffic_manager(client, tm_port)
            # print(dir(client))
            # print(traffic_manager.get_port())
            # -----------------------------------------------------------------------------
            # spawn npc
            # -----------------------------------------------------------------------------
            vehicles_list = util.spawn_vehicles_new(client, world, number_of_vehicles, True, traffic_manager, car_lights_on=False)
            print('spawned %d vehicles.' % (len(vehicles_list)))
            walkers_list, all_id = util.spawn_walkers_new(client, world, number_of_walkers, seedw)
            print('spawned %d walkers.' % (len(walkers_list)))

            _walkers = world.get_actors().filter('walker.pedestrian.*')
            # -----------------------------------------------------------------------------
            # spawn sensors
            # -----------------------------------------------------------------------------

            print('spawing sensors')

            #-----------------------------------
            # Randomly select walkers to avoid repetition
            walker_1, walker_2, walker_3, walker_4 = np.random.choice(_walkers, 4, replace=False)
            #-----------------------------------
            prev_1=walker_1.get_transform().rotation.yaw
            prev_2=walker_2.get_transform().rotation.yaw
            prev_3=walker_3.get_transform().rotation.yaw
            prev_4=walker_4.get_transform().rotation.yaw
            # walker 1 camera
            # walker_1 = random.choice(_walkers)
            cameras = {}
            cameras['wk1'] = spawn_cameras(world , walker_1, width, height, fov = 90)
            cameras['wk2'] = spawn_cameras(world , walker_2, width, height, fov = 90)
            cameras['wk3'] = spawn_cameras(world , walker_3, width, height, fov = 90)
            cameras['wk4'] = spawn_cameras(world , walker_4, width, height, fov = 90)
            
            # -----------------------------------------------------------------------------
            # start now
            # -----------------------------------------------------------------------------
            cnt = 0
            ct = 0
            print('Staring CarlySyncMode')
            # with CarlaSyncMode(world, cameras['wk1']['rgb'], cameras['wk1']['semseg'], cameras['wk1']['depth'], 
            #                           cameras['wk1']['rgb_right'], \
            #                           cameras['wk1']['rgb_left'], \
            #                           #
            #                           cameras['wk2']['rgb'], cameras['wk2']['semseg'], cameras['wk2']['depth'], 
            #                           cameras['wk2']['rgb_right'], \
            #                           cameras['wk2']['rgb_left'],  \
            #                           #
            #                           cameras['wk3']['rgb'], cameras['wk3']['semseg'], cameras['wk3']['depth'], 
            #                           cameras['wk3']['rgb_right'],\
            #                           cameras['wk3']['rgb_left'],  \
            #                           #
            #                           cameras['wk4']['rgb'], cameras['wk4']['semseg'], cameras['wk4']['depth'], 
            #                           cameras['wk4']['rgb_right'],  \
            #                           cameras['wk4']['rgb_left'], fps=10) as sync_mode:
            with CarlaSyncMode(world, cameras['wk1']['rgb'], cameras['wk1']['semseg'], cameras['wk1']['depth'], 
                                      cameras['wk1']['rgb_right'], cameras['wk1']['semseg_right'], cameras['wk1']['depth_right'], \
                                      cameras['wk1']['rgb_left'], cameras['wk1']['semseg_left'], cameras['wk1']['depth_left'], \
                                      #
                                      cameras['wk2']['rgb'], cameras['wk2']['semseg'], cameras['wk2']['depth'], 
                                      cameras['wk2']['rgb_right'], cameras['wk2']['semseg_right'], cameras['wk2']['depth_right'], \
                                      cameras['wk2']['rgb_left'], cameras['wk2']['semseg_left'], cameras['wk2']['depth_left'], \
                                      #
                                      cameras['wk3']['rgb'], cameras['wk3']['semseg'], cameras['wk3']['depth'], 
                                      cameras['wk3']['rgb_right'], cameras['wk3']['semseg_right'], cameras['wk3']['depth_right'], \
                                      cameras['wk3']['rgb_left'], cameras['wk3']['semseg_left'], cameras['wk3']['depth_left'], \
                                      #
                                      cameras['wk4']['rgb'], cameras['wk4']['semseg'], cameras['wk4']['depth'], 
                                      cameras['wk4']['rgb_right'], cameras['wk4']['semseg_right'], cameras['wk4']['depth_right'], \
                                      cameras['wk4']['rgb_left'], cameras['wk4']['semseg_left'], cameras['wk4']['depth_left'], fps=10) as sync_mode:
                # print("In with")
                while True:
                    # clock.tick()
                    # print("in loop")

                    if cnt%gap == 0 and cnt>=20:
                        weather = np.random.choice(WEATHERS[split])
                        weather_name = WEATHERS_DICT[weather]
                        world.set_weather(weather)

                    # snapshot, wk1_rgb, wk1_semseg, wk1_depth, wk1_rgb_right, wk1_rgb_left, \
                    #           wk2_rgb, wk2_semseg, wk2_depth, wk2_rgb_right, wk2_rgb_left, \
                    #           wk3_rgb, wk3_semseg, wk3_depth, wk3_rgb_right, wk3_rgb_left, \
                    #           wk4_rgb, wk4_semseg, wk4_depth, wk4_rgb_right, wk4_rgb_left = sync_mode.tick(timeout=10.0)

                    snapshot, wk1_rgb, wk1_semseg, wk1_depth, wk1_rgb_right, wk1_semseg_right, wk1_depth_right, wk1_rgb_left, wk1_semseg_left, wk1_depth_left, \
                              wk2_rgb, wk2_semseg, wk2_depth, wk2_rgb_right, wk2_semseg_right, wk2_depth_right, wk2_rgb_left, wk2_semseg_left, wk2_depth_left, \
                              wk3_rgb, wk3_semseg, wk3_depth, wk3_rgb_right, wk3_semseg_right, wk3_depth_right, wk3_rgb_left, wk3_semseg_left, wk3_depth_left, \
                              wk4_rgb, wk4_semseg, wk4_depth, wk4_rgb_right, wk4_semseg_right, wk4_depth_right, wk4_rgb_left, wk4_semseg_left, wk4_depth_left \
                              = sync_mode.tick(timeout=10.0)

                    if cnt%gap == 0 and cnt>=20:
                        cycle_start = time.time()
                        # weather = np.random.choice(WEATHERS[split]) # weather is shifted back 1 frame, but is correct ?
                        # weather_name = WEATHERS_DICT[weather]
                        # world.set_weather(weather)

                        # load image data
                        print("getting image: %012d"%ct)
                        wk1_rgb_array = util.get_image(wk1_rgb, 'rgb')
                        wk1_semseg_array = util.get_image(wk1_semseg, 'semantic_segmentation')
                        wk1_depth_array = util.get_image(wk1_depth, 'depth')
                        wk1_rgb_right_array = util.get_image(wk1_rgb_right, 'rgb')
                        wk1_semseg_right_array = util.get_image(wk1_semseg_right, 'semantic_segmentation')
                        wk1_depth_right_array = util.get_image(wk1_depth_right, 'depth')
                        wk1_rgb_left_array = util.get_image(wk1_rgb_left, 'rgb')
                        wk1_semseg_left_array = util.get_image(wk1_semseg_left, 'semantic_segmentation')
                        wk1_depth_left_array = util.get_image(wk1_depth_left, 'depth')

                        wk2_rgb_array = util.get_image(wk2_rgb, 'rgb')
                        wk2_semseg_array = util.get_image(wk2_semseg, 'semantic_segmentation')
                        wk2_depth_array = util.get_image(wk2_depth, 'depth')
                        wk2_rgb_right_array = util.get_image(wk2_rgb_right, 'rgb')
                        wk2_semseg_right_array = util.get_image(wk2_semseg_right, 'semantic_segmentation')
                        wk2_depth_right_array = util.get_image(wk2_depth_right, 'depth')
                        wk2_rgb_left_array = util.get_image(wk2_rgb_left, 'rgb')
                        wk2_semseg_left_array = util.get_image(wk2_semseg_left, 'semantic_segmentation')
                        wk2_depth_left_array = util.get_image(wk2_depth_left, 'depth')

                        wk3_rgb_array = util.get_image(wk3_rgb, 'rgb')
                        wk3_semseg_array = util.get_image(wk3_semseg, 'semantic_segmentation')
                        wk3_depth_array = util.get_image(wk3_depth, 'depth')
                        wk3_rgb_right_array = util.get_image(wk3_rgb_right, 'rgb')
                        wk3_semseg_right_array = util.get_image(wk3_semseg_right, 'semantic_segmentation')
                        wk3_depth_right_array = util.get_image(wk3_depth_right, 'depth')
                        wk3_rgb_left_array = util.get_image(wk3_rgb_left, 'rgb')
                        wk3_semseg_left_array = util.get_image(wk3_semseg_left, 'semantic_segmentation')
                        wk3_depth_left_array = util.get_image(wk3_depth_left, 'depth')

                        wk4_rgb_array = util.get_image(wk4_rgb, 'rgb')
                        wk4_semseg_array = util.get_image(wk4_semseg, 'semantic_segmentation')
                        wk4_depth_array = util.get_image(wk4_depth, 'depth')
                        wk4_rgb_right_array = util.get_image(wk4_rgb_right, 'rgb')
                        wk4_semseg_right_array = util.get_image(wk4_semseg_right, 'semantic_segmentation')
                        wk4_depth_right_array = util.get_image(wk4_depth_right, 'depth')
                        wk4_rgb_left_array = util.get_image(wk4_rgb_left, 'rgb')
                        wk4_semseg_left_array = util.get_image(wk4_semseg_left, 'semantic_segmentation')
                        wk4_depth_left_array = util.get_image(wk4_depth_left, 'depth')

                        # generate instruction and cluster
                        print("generating instruction: %012d"%ct)

                        # wk1
                        wk1_imgs = {}
                        wk1_semantics_imgs = {}
                        wk1_unfilled_imgs = {}

                        wk1_front_pts, wk1_front_tags = fme.process_scene(wk1_semseg_array.copy(), wk1_depth_array, tag_set, height_thresh=1.0, cam_height=0.8, rot=-90, ax=None)
                        wk1_right_pts, wk1_right_tags = fme.process_scene(wk1_semseg_right_array.copy(), wk1_depth_right_array, tag_set, height_thresh=1.0, cam_height=0.8, rot=-90, ax=None)
                        wk1_left_pts, wk1_left_tags = fme.process_scene(wk1_semseg_left_array.copy(), wk1_depth_left_array, tag_set, height_thresh=1.0, cam_height=0.8, rot=-90, ax=None)
                        
                        wk1_fm_front = Freemap(wk1_front_pts, wk1_front_tags)
                        wk1_fm_right = Freemap(wk1_right_pts, wk1_right_tags)
                        wk1_fm_left = Freemap(wk1_left_pts, wk1_left_tags)

                        wk1_imgs['front'], wk1_semantics_imgs['front'], wk1_unfilled_imgs['front'] = wk1_fm_front.get_img(m_per_pixel=0.02, max_distance=15, padding=5)
                        wk1_imgs['right'], wk1_semantics_imgs['right'], wk1_unfilled_imgs['right'] = wk1_fm_right.get_img(m_per_pixel=0.02, max_distance=15, padding=5)
                        wk1_imgs['left'], wk1_semantics_imgs['left'], wk1_unfilled_imgs['left'] = wk1_fm_left.get_img(m_per_pixel=0.02, max_distance=15, padding=5)

                        wk1_imgs['front'], wk1_semantics_imgs['front'] = preprocess_imgs(wk1_imgs['front'].copy(), wk1_semantics_imgs['front'].copy())
                        wk1_imgs['right'], wk1_semantics_imgs['right'] = preprocess_imgs(wk1_imgs['right'].copy(), wk1_semantics_imgs['right'].copy())
                        wk1_imgs['left'], wk1_semantics_imgs['left'] = preprocess_imgs(wk1_imgs['left'].copy(), wk1_semantics_imgs['left'].copy())
                        #print(wk1_semantics_imgs['front'])
                        # wk1_sem=convert(wk1_semantics_imgs['front'])
                        # wk1_sem_right=convert(wk1_semantics_imgs['right'])
                        # wk1_sem_left=convert(wk1_semantics_imgs['left'])
                        #print(wk1_sem.shape)
                        wk1_inst = generate_multiple_random_instructions(inst_per_image, path_finder, wk1_imgs, wk1_unfilled_imgs, wk1_semantics_imgs, min_s = 1,max_s=args.preview_meters)
                        # np.save(str(wk_instruction_path[0]/('%012d_front.npy' % ct)), wk1_inst[0])
                        # np.save(str(wk_instruction_path[0]/('%012d_left.npy' % ct)), wk1_inst[1])
                        # np.save(str(wk_instruction_path[0]/('%012d_right.npy' % ct)), wk1_inst[2])

                        #wk2
                        wk2_imgs = {}
                        wk2_semantics_imgs = {}
                        wk2_unfilled_imgs = {}

                        wk2_front_pts, wk2_front_tags = fme.process_scene(wk2_semseg_array.copy(), wk2_depth_array, tag_set, height_thresh=1.0, cam_height=0.8, rot=-90, ax=None)
                        wk2_right_pts, wk2_right_tags = fme.process_scene(wk2_semseg_right_array.copy(), wk2_depth_right_array, tag_set, height_thresh=1.0, cam_height=0.8, rot=-90, ax=None)
                        wk2_left_pts, wk2_left_tags = fme.process_scene(wk2_semseg_left_array.copy(), wk2_depth_left_array, tag_set, height_thresh=1.0, cam_height=0.8, rot=-90, ax=None)

                        wk2_fm_front = Freemap(wk2_front_pts, wk2_front_tags)
                        wk2_fm_right = Freemap(wk2_right_pts, wk2_right_tags)
                        wk2_fm_left = Freemap(wk2_left_pts, wk2_left_tags)

                        wk2_imgs['front'], wk2_semantics_imgs['front'], wk2_unfilled_imgs['front'] = wk2_fm_front.get_img(m_per_pixel=0.02, max_distance=15, padding=5)
                        wk2_imgs['right'], wk2_semantics_imgs['right'], wk2_unfilled_imgs['right'] = wk2_fm_right.get_img(m_per_pixel=0.02, max_distance=15, padding=5)
                        wk2_imgs['left'], wk2_semantics_imgs['left'], wk2_unfilled_imgs['left'] = wk2_fm_left.get_img(m_per_pixel=0.02, max_distance=15, padding=5)

                        wk2_imgs['front'], wk2_semantics_imgs['front'] = preprocess_imgs(wk2_imgs['front'].copy(), wk2_semantics_imgs['front'].copy())
                        wk2_imgs['right'], wk2_semantics_imgs['right'] = preprocess_imgs(wk2_imgs['right'].copy(), wk2_semantics_imgs['right'].copy())
                        wk2_imgs['left'], wk2_semantics_imgs['left'] = preprocess_imgs(wk2_imgs['left'].copy(), wk2_semantics_imgs['left'].copy())

                        # wk2_sem=convert(wk2_semantics_imgs['front'])
                        # wk2_sem_right=convert(wk2_semantics_imgs['right'])
                        # wk2_sem_left=convert(wk2_semantics_imgs['left'])

                        wk2_inst = generate_multiple_random_instructions(inst_per_image, path_finder, wk2_imgs, wk2_unfilled_imgs, wk2_semantics_imgs, min_s = 1,max_s=args.preview_meters)
                        # np.save(str(wk_instruction_path[1]/('%012d_front.npy' % ct)), wk2_inst[0])
                        # np.save(str(wk_instruction_path[1]/('%012d_left.npy' % ct)), wk2_inst[1])
                        # np.save(str(wk_instruction_path[1]/('%012d_right.npy' % ct)), wk2_inst[2])

                        # wk3
                        wk3_imgs = {}
                        wk3_semantics_imgs = {}
                        wk3_unfilled_imgs = {}

                        wk3_front_pts, wk3_front_tags = fme.process_scene(wk3_semseg_array.copy(), wk3_depth_array, tag_set, height_thresh=1.0, cam_height=0.8, rot=-90, ax=None)
                        wk3_right_pts, wk3_right_tags = fme.process_scene(wk3_semseg_right_array.copy(), wk3_depth_right_array, tag_set, height_thresh=1.0, cam_height=0.8, rot=-90, ax=None)
                        wk3_left_pts, wk3_left_tags = fme.process_scene(wk3_semseg_left_array.copy(), wk3_depth_left_array, tag_set, height_thresh=1.0, cam_height=0.8, rot=-90, ax=None)

                        wk3_fm_front = Freemap(wk3_front_pts, wk3_front_tags)
                        wk3_fm_right = Freemap(wk3_right_pts, wk3_right_tags)
                        wk3_fm_left = Freemap(wk3_left_pts, wk3_left_tags)

                        wk3_imgs['front'], wk3_semantics_imgs['front'], wk3_unfilled_imgs['front'] = wk3_fm_front.get_img(m_per_pixel=0.02, max_distance=15, padding=5)
                        wk3_imgs['right'], wk3_semantics_imgs['right'], wk3_unfilled_imgs['right'] = wk3_fm_right.get_img(m_per_pixel=0.02, max_distance=15, padding=5)
                        wk3_imgs['left'], wk3_semantics_imgs['left'], wk3_unfilled_imgs['left'] = wk3_fm_left.get_img(m_per_pixel=0.02, max_distance=15, padding=5)

                        wk3_imgs['front'], wk3_semantics_imgs['front'] = preprocess_imgs(wk3_imgs['front'].copy(), wk3_semantics_imgs['front'].copy())
                        wk3_imgs['right'], wk3_semantics_imgs['right'] = preprocess_imgs(wk3_imgs['right'].copy(), wk3_semantics_imgs['right'].copy())
                        wk3_imgs['left'], wk3_semantics_imgs['left'] = preprocess_imgs(wk3_imgs['left'].copy(), wk3_semantics_imgs['left'].copy())

                        # wk3_sem=convert(wk3_semantics_imgs['front'])
                        # wk3_sem_right=convert(wk3_semantics_imgs['right'])
                        # wk3_sem_left=convert(wk3_semantics_imgs['left'])

                        wk3_inst = generate_multiple_random_instructions(inst_per_image, path_finder, wk3_imgs, wk3_unfilled_imgs, wk3_semantics_imgs, min_s = 1,max_s=args.preview_meters)
                        # np.save(str(wk_instruction_path[2]/('%012d_front.npy' % ct)), wk3_inst[0])
                        # np.save(str(wk_instruction_path[2]/('%012d_left.npy' % ct)), wk3_inst[1])
                        # np.save(str(wk_instruction_path[2]/('%012d_right.npy' % ct)), wk3_inst[2])

                        # wk4
                        wk4_imgs = {}
                        wk4_semantics_imgs = {}
                        wk4_unfilled_imgs = {}

                        wk4_front_pts, wk4_front_tags = fme.process_scene(wk4_semseg_array.copy(), wk4_depth_array, tag_set, height_thresh=1.0, cam_height=0.8, rot=-90, ax=None)
                        wk4_right_pts, wk4_right_tags = fme.process_scene(wk4_semseg_right_array.copy(), wk4_depth_right_array, tag_set, height_thresh=1.0, cam_height=0.8, rot=-90, ax=None)
                        wk4_left_pts, wk4_left_tags = fme.process_scene(wk4_semseg_left_array.copy(), wk4_depth_left_array, tag_set, height_thresh=1.0, cam_height=0.8, rot=-90, ax=None)

                        wk4_fm_front = Freemap(wk4_front_pts, wk4_front_tags)
                        wk4_fm_right = Freemap(wk4_right_pts, wk4_right_tags)
                        wk4_fm_left = Freemap(wk4_left_pts, wk4_left_tags)

                        wk4_imgs['front'], wk4_semantics_imgs['front'], wk4_unfilled_imgs['front'] = wk4_fm_front.get_img(m_per_pixel=0.02, max_distance=15, padding=5)
                        wk4_imgs['right'], wk4_semantics_imgs['right'], wk4_unfilled_imgs['right'] = wk4_fm_right.get_img(m_per_pixel=0.02, max_distance=15, padding=5)
                        wk4_imgs['left'], wk4_semantics_imgs['left'], wk4_unfilled_imgs['left'] = wk4_fm_left.get_img(m_per_pixel=0.02, max_distance=15, padding=5)

                        wk4_imgs['front'], wk4_semantics_imgs['front'] = preprocess_imgs(wk4_imgs['front'].copy(), wk4_semantics_imgs['front'].copy())
                        wk4_imgs['right'], wk4_semantics_imgs['right'] = preprocess_imgs(wk4_imgs['right'].copy(), wk4_semantics_imgs['right'].copy())
                        wk4_imgs['left'], wk4_semantics_imgs['left'] = preprocess_imgs(wk4_imgs['left'].copy(), wk4_semantics_imgs['left'].copy())

                        # wk4_sem=convert(wk4_semantics_imgs['front'])
                        # wk4_sem_right=convert(wk4_semantics_imgs['right'])
                        # wk4_sem_left=convert(wk4_semantics_imgs['left'])

                        wk4_inst = generate_multiple_random_instructions(inst_per_image, path_finder, wk4_imgs, wk4_unfilled_imgs, wk4_semantics_imgs, min_s = 1,max_s=args.preview_meters)
                        # np.save(str(wk_instruction_path[3]/('%012d_front.npy' % ct)), wk4_inst[0])
                        # np.save(str(wk_instruction_path[3]/('%012d_left.npy' % ct)), wk4_inst[1])
                        # np.save(str(wk_instruction_path[3]/('%012d_right.npy' % ct)), wk4_inst[2])                    
                        # save image data

                        print("saving image data: %012d"%ct)
                        # wk1
                        Image.fromarray(np.uint8(wk1_rgb_array)).save(wk_path[0] / ('%012d_front.jpg' % ct))
                        # Image.fromarray(np.uint8(wk1_rgb_right_array)).save(wk_path[0] / ('%012d_right.jpg' % ct))
                        # Image.fromarray(np.uint8(wk1_rgb_left_array)).save(wk_path[0] / ('%012d_left.jpg' % ct))
                        # Image.fromarray(np.uint8(wk1_semseg_array)).save(wk_path[0] / ('%012d_sem.jpg' % ct))
                        # Image.fromarray(np.uint8(wk1_semseg_right_array)).save(wk_path[0] / ('%012d_sem_right.jpg' % ct))
                        # Image.fromarray(np.uint8(wk1_semseg_left_array)).save(wk_path[0] / ('%012d_sem_left.jpg' % ct))
                        arr=check_affordance(np.flipud(wk1_imgs['front']))
                        # Image.fromarray(np.uint8((wk1_imgs['front']/3)*255)).save(wk_path[1] / ('trial.jpg'))
                        # print(wk1_imgs['front'])
                        # print(arr)
                        np.save(str(wk_path[0]/('%012d_front.npy' % ct)), np.concatenate((arr.astype(np.float32),np.array([walker_1.get_transform().rotation.yaw,walker_1.get_velocity().length()],dtype=np.float32))))
                        #arr1=check_affordance(np.flipud(wk1_imgs['right']))
                        # np.save(str(wk_path[0]/('%012d_right.npy' % ct)), np.concatenate((arr1.astype(np.float32),np.array([walker_1.get_transform().rotation.yaw-prev_1-(np.pi/4),walker_1.get_velocity().length()],dtype=np.float32))))
                        # arr2=check_affordance(np.flipud(wk1_imgs['left']))
                        # np.save(str(wk_path[0]/('%012d_left.npy' % ct)), np.concatenate((arr2.astype(np.float32),np.array([walker_1.get_transform().rotation.yaw-prev_1+(np.pi/4),walker_1.get_velocity().length()],dtype=np.float32))))
                        # #Image.fromarray(np.uint8(wk1_rgb_right_array)).save(wk_rgb_path[0] / ('%012d_right.jpg' % ct))
                        # Image.fromarray(np.uint8((np.flipud(wk1_imgs['front'])/3)*255)).save(wk_path[0] / ('%012d_BEV_bw.jpg' % ct))
                        # Image.fromarray(np.uint8((np.flipud(wk1_imgs['right'])/3)*255)).save(wk_path[0] / ('%012d_BEV_bw_right.jpg' % ct))
                        # Image.fromarray(np.uint8((np.flipud(wk1_imgs['left'])/3)*255)).save(wk_path[0] / ('%012d_BEV_bw_left.jpg' % ct))
                        # Image.fromarray(np.uint8(wk1_sem)).save(wk_path[0] / ('%012d_BEV.jpg' % ct))
                        # Image.fromarray(np.uint8(wk1_sem_right)).save(wk_path[0] / ('%012d_BEV_right.jpg' % ct))
                        # Image.fromarray(np.uint8(wk1_sem_left)).save(wk_path[0] / ('%012d_BEV_left.jpg' % ct))

                        Image.fromarray(np.uint8(wk2_rgb_array)).save(wk_path[1] / ('%012d_front.jpg' % ct))
                        # Image.fromarray(np.uint8(wk2_rgb_right_array)).save(wk_path[1] / ('%012d_right.jpg' % ct))
                        # Image.fromarray(np.uint8(wk2_rgb_left_array)).save(wk_path[1] / ('%012d_left.jpg' % ct))
                        # Image.fromarray(np.uint8(wk2_semseg_array)).save(wk_path[1] / ('%012d_sem.jpg' % ct))
                        # Image.fromarray(np.uint8(wk2_semseg_right_array)).save(wk_path[1] / ('%012d_sem_right.jpg' % ct))
                        # Image.fromarray(np.uint8(wk2_semseg_left_array)).save(wk_path[1] / ('%012d_sem_left.jpg' % ct))
                        arr=check_affordance(np.flipud(wk2_imgs['front']))
                        np.save(str(wk_path[1]/('%012d_front.npy' % ct)), np.concatenate((arr.astype(np.float32),np.array([walker_2.get_transform().rotation.yaw,walker_2.get_velocity().length()],dtype=np.float32))))
                        # arr1=check_affordance(np.flipud(wk2_imgs['right']))
                        # np.save(str(wk_path[1]/('%012d_right.npy' % ct)), np.concatenate((arr1.astype(np.float32),np.array([walker_2.get_transform().rotation.yaw-prev_2-(np.pi/4),walker_2.get_velocity().length()],dtype=np.float32))))
                        # arr2=check_affordance(np.flipud(wk2_imgs['left']))
                        # np.save(str(wk_path[1]/('%012d_left.npy' % ct)), np.concatenate((arr2.astype(np.float32),np.array([walker_2.get_transform().rotation.yaw-prev_2+(np.pi/4),walker_2.get_velocity().length()],dtype=np.float32))))
                        # np.save(str(wk_path[1]/('%012d_front.npy' % ct)), np.array(walker_2.get_transform().rotation.yaw-prev_2))
                        # np.save(str(wk_path[1]/('%012d_right.npy' % ct)), np.array(walker_2.get_transform().rotation.yaw-prev_2-(np.pi/4)))
                        # np.save(str(wk_path[1]/('%012d_left.npy' % ct)), np.array(walker_2.get_transform().rotation.yaw-prev_2+(np.pi/4)))
                        #Image.fromarray(np.uint8(wk1_rgb_right_array)).save(wk_rgb_path[0] / ('%012d_right.jpg' % ct))
                        #Image.fromarray(np.uint8((np.flipud(wk2_imgs['front'])/3)*255)).save(wk_path[1] / ('%012d_BEV_bw.jpg' % ct))
                        # Image.fromarray(np.uint8((np.flipud(wk2_imgs['right'])/3)*255)).save(wk_path[1] / ('%012d_BEV_bw_right.jpg' % ct))
                        # Image.fromarray(np.uint8((np.flipud(wk2_imgs['left'])/3)*255)).save(wk_path[1] / ('%012d_BEV_bw_left.jpg' % ct))
                        # Image.fromarray(np.uint8(wk2_sem)).save(wk_path[1] / ('%012d_BEV.jpg' % ct))
                        # Image.fromarray(np.uint8(wk2_sem_right)).save(wk_path[1] / ('%012d_BEV_right.jpg' % ct))
                        # Image.fromarray(np.uint8(wk2_sem_left)).save(wk_path[1] / ('%012d_BEV_left.jpg' % ct))

                        Image.fromarray(np.uint8(wk3_rgb_array)).save(wk_path[2] / ('%012d_front.jpg' % ct))
                        # Image.fromarray(np.uint8(wk3_rgb_right_array)).save(wk_path[2] / ('%012d_right.jpg' % ct))
                        # Image.fromarray(np.uint8(wk3_rgb_left_array)).save(wk_path[2] / ('%012d_left.jpg' % ct))
                        # Image.fromarray(np.uint8(wk3_semseg_array)).save(wk_path[2] / ('%012d_sem.jpg' % ct))
                        # Image.fromarray(np.uint8(wk3_semseg_right_array)).save(wk_path[2] / ('%012d_sem_right.jpg' % ct))
                        # Image.fromarray(np.uint8(wk3_semseg_left_array)).save(wk_path[2] / ('%012d_sem_left.jpg' % ct))
                        arr=check_affordance(np.flipud(wk3_imgs['front']))
                        np.save(str(wk_path[2]/('%012d_front.npy' % ct)), np.concatenate((arr.astype(np.float32),np.array([walker_3.get_transform().rotation.yaw,walker_3.get_velocity().length()],dtype=np.float32))))
                        # arr1=check_affordance(np.flipud(wk3_imgs['right']))
                        # np.save(str(wk_path[2]/('%012d_right.npy' % ct)), np.concatenate((arr1.astype(np.float32),np.array([walker_3.get_transform().rotation.yaw-prev_3-(np.pi/4),walker_3.get_velocity().length()],dtype=np.float32))))
                        # arr2=check_affordance(np.flipud(wk3_imgs['left']))
                        # np.save(str(wk_path[2]/('%012d_left.npy' % ct)), np.concatenate((arr2.astype(np.float32),np.array([walker_3.get_transform().rotation.yaw-prev_3+(np.pi/4),walker_3.get_velocity().length()],dtype=np.float32))))
                        # np.save(str(wk_path[2]/('%012d_front.npy' % ct)), np.array(walker_3.get_transform().rotation.yaw-prev_3))
                        # np.save(str(wk_path[2]/('%012d_right.npy' % ct)), np.array(walker_3.get_transform().rotation.yaw-prev_3-(np.pi/4)))
                        # np.save(str(wk_path[2]/('%012d_left.npy' % ct)), np.array(walker_3.get_transform().rotation.yaw-prev_3+(np.pi/4)))
                        #Image.fromarray(np.uint8(wk1_rgb_right_array)).save(wk_rgb_path[0] / ('%012d_right.jpg' % ct))
                        #Image.fromarray(np.uint8((np.flipud(wk3_imgs['front'])/3)*255)).save(wk_path[2] / ('%012d_BEV_bw.jpg' % ct))
                        # Image.fromarray(np.uint8((np.flipud(wk3_imgs['right'])/3)*255)).save(wk_path[2] / ('%012d_BEV_bw_right.jpg' % ct))
                        # Image.fromarray(np.uint8((np.flipud(wk3_imgs['left'])/3)*255)).save(wk_path[2] / ('%012d_BEV_bw_left.jpg' % ct))
                        # Image.fromarray(np.uint8(wk3_sem)).save(wk_path[2] / ('%012d_BEV.jpg' % ct))
                        # Image.fromarray(np.uint8(wk3_sem_right)).save(wk_path[2] / ('%012d_BEV_right.jpg' % ct))
                        # Image.fromarray(np.uint8(wk3_sem_left)).save(wk_path[2] / ('%012d_BEV_left.jpg' % ct))

                        Image.fromarray(np.uint8(wk4_rgb_array)).save(wk_path[3] / ('%012d_front.jpg' % ct))
                        # Image.fromarray(np.uint8(wk4_rgb_right_array)).save(wk_path[3] / ('%012d_right.jpg' % ct))
                        # Image.fromarray(np.uint8(wk4_rgb_left_array)).save(wk_path[3] / ('%012d_left.jpg' % ct))
                        # Image.fromarray(np.uint8(wk4_semseg_array)).save(wk_path[3] / ('%012d_sem.jpg' % ct))
                        # Image.fromarray(np.uint8(wk4_semseg_right_array)).save(wk_path[3] / ('%012d_sem_right.jpg' % ct))
                        # Image.fromarray(np.uint8(wk4_semseg_left_array)).save(wk_path[3] / ('%012d_sem_left.jpg' % ct))
                        arr=check_affordance(np.flipud(wk4_imgs['front']))
                        np.save(str(wk_path[3]/('%012d_front.npy' % ct)), np.concatenate((arr.astype(np.float32),np.array([walker_4.get_transform().rotation.yaw,walker_4.get_velocity().length()],dtype=np.float32))))
                        # arr1=check_affordance(np.flipud(wk4_imgs['right']))
                        # np.save(str(wk_path[3]/('%012d_right.npy' % ct)), np.concatenate((arr1.astype(np.float32),np.array([walker_4.get_transform().rotation.yaw-prev_4-(np.pi/4),walker_4.get_velocity().length()],dtype=np.float32))))
                        # arr2=check_affordance(np.flipud(wk4_imgs['left']))
                        # np.save(str(wk_path[3]/('%012d_left.npy' % ct)), np.concatenate((arr2.astype(np.float32),np.array([walker_4.get_transform().rotation.yaw-prev_4+(np.pi/4),walker_4.get_velocity().length()],dtype=np.float32))))
                        # np.save(str(wk_path[3]/('%012d_front.npy' % ct)), np.array(walker_4.get_transform().rotation.yaw-prev_4))
                        # np.save(str(wk_path[3]/('%012d_right.npy' % ct)), np.array(walker_4.get_transform().rotation.yaw-prev_4-(np.pi/4)))
                        # np.save(str(wk_path[3]/('%012d_left.npy' % ct)), np.array(walker_4.get_transform().rotation.yaw-prev_4+(np.pi/4)))
                        #Image.fromarray(np.uint8(wk1_rgb_right_array)).save(wk_rgb_path[0] / ('%012d_right.jpg' % ct))
                        # Image.fromarray(np.uint8((np.flipud(wk4_imgs['front'])/3)*255)).save(wk_path[3] / ('%012d_BEV_bw.jpg' % ct))
                        # Image.fromarray(np.uint8((np.flipud(wk4_imgs['right'])/3)*255)).save(wk_path[3] / ('%012d_BEV_bw_right.jpg' % ct))
                        # Image.fromarray(np.uint8((np.flipud(wk4_imgs['left'])/3)*255)).save(wk_path[3] / ('%012d_BEV_bw_left.jpg' % ct))
                        # Image.fromarray(np.uint8(wk4_sem)).save(wk_path[3] / ('%012d_BEV.jpg' % ct))
                        # Image.fromarray(np.uint8(wk4_sem_right)).save(wk_path[3] / ('%012d_BEV_right.jpg' % ct))
                        # Image.fromarray(np.uint8(wk4_sem_left)).save(wk_path[3] / ('%012d_BEV_left.jpg' % ct))
                        #Image.fromarray(np.uint8(wk1_semantics_image['front'])).save(wk_semantic_path[0] / ('%012d_BEV_real.jpg' % ct))
                        #Image.fromarray(np.uint8((wk1_imgs['right']/3)*255)).save(wk_semantic_path[0] / ('%012d_BEV_right.jpg' % ct))
                        #Image.fromarray(np.uint8((wk1_imgs['left']/3)*255)).save(wk_semantic_path[0] / ('%012d_BEV_left.jpg' % ct))

                        # # wk2
                        # Image.fromarray(np.uint8(wk2_rgb_array)).save(wk_rgb_path[1] / ('%012d_front.jpg' % ct))
                        # Image.fromarray(np.uint8(wk2_semseg_array)).save(wk_semantic_path[1] / ('%012d.jpg' % ct))
                        # #np.save(str(wk_depth_path[1]/('%012d.npy' % ct)), wk2_depth_array)
                        # #Image.fromarray(np.uint8(wk2_rgb_right_array)).save(wk_rgb_path[1] / ('%012d_right.jpg' % ct))
                        # #Image.fromarray(np.uint8(wk2_rgb_left_array)).save(wk_rgb_path[1] / ('%012d_left.jpg' % ct))
                        # Image.fromarray(np.uint8((wk2_imgs['front']/3)*255)).save(wk_semantic_path[1] / ('%012d_BEV.jpg' % ct))
                        # #Image.fromarray(np.uint8(wk2_front_pts)).save(wk_semantic_path[1] / ('%012d_BEV_real.jpg' % ct))
                        
                        # # wk3
                        # Image.fromarray(np.uint8(wk3_rgb_array)).save(wk_rgb_path[2] / ('%012d_front.jpg' % ct))
                        # Image.fromarray(np.uint8(wk3_semseg_array)).save(wk_semantic_path[2] / ('%012d.jpg' % ct))
                        # # np.save(str(wk_depth_path[2]/('%012d.npy' % ct)), wk3_depth_array)
                        # # Image.fromarray(np.uint8(wk3_rgb_right_array)).save(wk_rgb_path[2] / ('%012d_right.jpg' % ct))
                        # # Image.fromarray(np.uint8(wk3_rgb_left_array)).save(wk_rgb_path[2] / ('%012d_left.jpg' % ct))
                        # Image.fromarray(np.uint8((wk3_imgs['front']/3)*255)).save(wk_semantic_path[2] / ('%012d_BEV.jpg' % ct))
                        # #Image.fromarray(np.uint8(wk3_front_pts)).save(wk_semantic_path[2] / ('%012d_BEV_real.jpg' % ct))

                        # # wk4
                        # Image.fromarray(np.uint8(wk4_rgb_array)).save(wk_rgb_path[3] / ('%012d_front.jpg' % ct))
                        # Image.fromarray(np.uint8(wk4_semseg_array)).save(wk_semantic_path[3] / ('%012d.jpg' % ct))
                        # # np.save(str(wk_depth_path[3]/('%012d.npy' % ct)), wk4_depth_array)
                        # # Image.fromarray(np.uint8(wk4_rgb_right_array)).save(wk_rgb_path[3] / ('%012d_right.jpg' % ct))
                        # # Image.fromarray(np.uint8(wk4_rgb_left_array)).save(wk_rgb_path[3] / ('%012d_left.jpg' % ct))
                        # Image.fromarray(np.uint8((wk4_imgs['front']/3)*255)).save(wk_semantic_path[3] / ('%012d_BEV.jpg' % ct))
                        # #Image.fromarray(np.uint8(wk4_front_pts)).save(wk_semantic_path[3] / ('%012d_BEV_real.jpg' % ct))

                        # Save meta data
                        meta_data = {'id': '%012d' % ct, 'height': height,
                                        'width': width, 'date_captured': time.asctime(time.localtime(time.time())),
                                        'town': town, 'time': eps, #'weather': weather_name, 
                                        'vehicle_number': number_of_vehicles, 'pedestrian_number': number_of_walkers, 'percent_disabled': percent_disabled,
                                        'tm_seed': tm_seed, 'seedw': seedw, 'max_frame': max_frame, 'frame_gap':gap}
                
                        np.save(str(save_dir / 'meta' / ('%012d_meta.npy' % ct)), meta_data)

                        prev_1=walker_1.get_transform().rotation.yaw
                        prev_2=walker_2.get_transform().rotation.yaw
                        prev_3=walker_3.get_transform().rotation.yaw
                        prev_4=walker_4.get_transform().rotation.yaw

                        ct += 1
                        print('completed %012d in:'%ct, cycle_start - time.time())

                    if ct > max_frame:
                        break

                    cnt += 1
                    

        except Exception:
            traceback.print_exc()
            print("Something Wrong")

        finally:

            print('destroying actors.')
            for actor in actor_list:
                actor.destroy()

            print('\ndestroying %d vehicles' % len(vehicles_list))
            client.apply_batch([carla.command.DestroyActor(x) for x in vehicles_list])

            # stop walker controllers (list is [controller, actor, controller, actor ...])
            all_actors = world.get_actors(all_id)
            for i in range(0, len(all_id), 2):
                all_actors[i].stop()

            print('\ndestroying %d walkers' % len(walkers_list))
            client.apply_batch([carla.command.DestroyActor(x) for x in all_id])
            for camera in cameras.values():
                for x in camera:
                    x.destroy()
            # client.apply_batch([x.destroy() for camera in cameras.values() for x in camera.values()])
            print('here1')
            settings = world.get_settings()
            print('here2')
            settings.synchronous_mode = False
            print('here3')
            settings.fixed_delta_seconds = None
            print('here4')
            # world.apply_settings(settings)
            print('here5')
            traffic_manager.set_synchronous_mode(False)
            print('here6')

            time.sleep(3)
            print('here7')

            # pygame.quit()
            gc_fb = gc.collect()
            print('gc: ', gc_fb)
            print('done.')
        print('here?.')



if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='Data collection for BVI pedestrian in carla simulation')
    parser.add_argument('--session-id', metavar='S', type=int,
                        help='Session ID for this paticular process, used in file names of data collected')

    parser.add_argument('--time-str', type=str, help='Time when running collection, used as file name.')

    parser.add_argument('--carla-port', metavar='C', type=int, default=2000,
                    help='Carla server port for client to connect to')

    parser.add_argument('--tm-port', metavar='T', type=int, default=8000,
                        help='Traffic manager port for this paticular process')

    parser.add_argument('--max-frame', metavar='M', type=int, default=40000,
                        help='Maximum frames before the simulation ends')

    parser.add_argument('--frame-gap', metavar='F', type=int, default=20,
                        help='Number of frames before gathering data')
    
    parser.add_argument('--town', type=str, default='Town10HD', help='Map name')
    parser.add_argument('--vehicles', type=int, default=0, help='Number of vehicles spawned')
    parser.add_argument('--walkers', type=int, default=0, help='Number of  walker spawned')
    parser.add_argument('--epochs', type=int, default=1, help='Number of epochs to run')
    parser.add_argument('--preview_meters', type=int, default=5, help='max range of goal selection')

    args = parser.parse_args()                    
    main(args)
