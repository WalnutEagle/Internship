import os
import sys
import argparse
from shutil import copyfile, rmtree
from pathlib import Path
import numpy as np
import re
#
# Merge data collected in a batch according to their Map
# - Set all data to trainval
# - ignore problematic data
# - aggregate all data to a single set of data
# - rename data entry

TARGET_DIR = Path("/home/zanming/carla_dataset/vi_dataset/batch_5_merged/")


# TO_BE_MERGED = {"annotation":["_front", "_back", "_left", "_right","_wk1", "_wk2", "_meta"], 
#                 "depth":["_front", "_back", "_left", "_right","_wk1", "_wk2"], 
#                 "instance":["_front", "_back", "_left", "_right","_wk1", "_wk2"], 
#                 "rgb":["_front", "_back", "_left", "_right","_wk1", "_wk2"]}

TO_BE_MERGED = {"instruction":["_front", "_left", "_right"], 
                "rgb":["_front", "_left", "_right"]}

TOWNS = ['Town01', 'Town02', 'Town03', 'Town05', 'Town10HD']
IGNORE = ['record.md']


CORSE_FILTER = []

FILTER = {}


#================================================
# Setting for batch_2022_01_20 
#------------------------------------------------

# CORSE_FILTER = ['2022_01_15_07_21_17/session_2/Town02', 
#                '2022_01_21_07_44_27/session_0/Town01', 
#                '2022_01_21_07_44_27/session_1/Town03']

# FILTER = {'2022_01_09_07_42_12/session_0/Town03/001':["_front", "_left", "_right"],
#           '2022_01_09_07_42_12/session_0/Town03/004':["_front", "_right"],
#           '2022_01_09_07_42_12/session_1/Town05/003':["_front", "_left", "_right"],
#           '2022_01_09_07_42_12/session_1/Town05/004':["_front"],
#           '2022_01_09_07_42_12/session_1/Town05/006':["_front", "_back"],
#           '2022_01_09_07_42_12/session_1/Town05/007':["_front"],
#           '2022_01_09_07_42_12/session_2/Town10HD/001':["_front"],
#           '2022_01_12_18_30_00/session_2/Town10HD/002':["_front", "_right"],
#           '2022_01_12_23_30_00/session_0/Town03/001':["_wk1"],
#           '2022_01_12_23_30_00/session_0/Town03/002':["_front", "_back", "_left", "_right"],
#           '2022_01_15_07_21_17/session_0/Town01/001':["_front","_left", "_right"],
#           '2022_01_15_07_21_17/session_0/Town01/006':["_front","_back", "_right"],
#           '2022_01_15_07_21_17/session_1/Town01/002':["_front", "_right"],
#           '2022_01_16_17_00_00/session_1/Town01/003':["_front"],
#           '2022_01_21_07_44_27/session_2/Town10HD/002':["_front", "_back", "_left", "_right"]}

#================================================


def rename_file(old_path, new_path):
    os.rename(str(old_path), str(new_path))
    # print("old name: ", old_path)
    # print("new name: ", new_path)
    return


def copy_to(old_path, new_path):
    copyfile(old_path, new_path)
    # print("from: ", old_path)
    # print("to: ", new_path)
    return



def merge_data(root, merge_dirs, output_dir):
    # merge foledrs under data_dir with same folder name
    # reindex files (keep consistency)
    merge_dirs.sort()
    need_filter = False
    file_sum = 0
    for d in merge_dirs:
        meta_dir = root/d/'meta'
        meta_files = os.listdir(meta_dir)
        meta_files = sorted(meta_files, key= lambda x: int(x.split("_")[0]))
        for wk in ['wk1', 'wk2', 'wk3', 'wk4']:
            file_sum += len(meta_files)*3
            f = 'instruction'
            _dir = root/d/wk/f
            print("Checking: ", _dir)
            inst_ = {}
            for s in TO_BE_MERGED[f]:
                file_list = [_ for _ in os.listdir(_dir) if re.match('[0-9]+%s.*' % s, _)]
                inst_[s] = len(file_list)

            f = 'rgb'
            _dir = root/d/wk/f
            print("Checking: ", _dir)
            rgb_ = {}
            for s in TO_BE_MERGED[f]:
                if need_filter and s in FILTER[d]:
                    continue
                file_list = [_ for _ in os.listdir(_dir) if re.match('[0-9]+%s.*' % s, _)]
                rgb_[s] = len(file_list)
        

            # check meta number match
            for s in inst_.keys():
                print("[", s, "]", " inst: ", inst_[s], ", meta: ", len(meta_files))
                assert (inst_[s] == len(meta_files))

            # check meta number match
            for s in rgb_.keys():
                print("[", s, "]", " inst: ", rgb_[s], ", meta: ", len(meta_files))
                assert (rgb_[s] == len(meta_files))

            # check number of inst match number of rgb
            for s in inst_.keys():
                print("[", s, "]", " inst: ", inst_[s], ", rgb: ", rgb_[s])
                assert (inst_[s] == rgb_[s])
    print("Total: ", file_sum)

def main(args):
    batch_dir = Path(args.dir)
    target_dir = batch_dir/'..'/(batch_dir.name+'_merged')
    print('target: ', target_dir)
    files = os.listdir(batch_dir)
    files.sort()
    print("Executing on : ", files)

    for town in TOWNS:
        merge_dirs = []
        for date_f in files:
            if date_f in IGNORE:
                continue
            session_dir = os.listdir(str(batch_dir/date_f))
            session_dir.sort()
            for sess_f in session_dir:
                if date_f+'/'+sess_f+'/'+town in CORSE_FILTER:
                    print("skipped: ", date_f+'/'+sess_f+'/'+town)
                    continue
                if os.path.exists(str(batch_dir/date_f/sess_f/town)):
                    episode_dir = os.listdir(str(batch_dir/date_f/sess_f/town))
                    episode_dir.sort()
                    merge_dirs += [date_f+'/'+sess_f+'/'+town+'/'+epsd_f for epsd_f in episode_dir]
        print('merging: ', merge_dirs)
        merge_data(batch_dir, merge_dirs, target_dir/town)
    return


if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument("--dir", default=None,
                        required=True, help="Batch directory")
    args = parser.parse_args()
    main(args)
    # source = Path("/data2/zanming/data/xworld_9_13/batch_2022_01_20/2022_01_10_12_20_00/session_2/Town10HD")
    # target = Path('/data2/zanming/data/TESTING')
    # merge_data(source, target)
