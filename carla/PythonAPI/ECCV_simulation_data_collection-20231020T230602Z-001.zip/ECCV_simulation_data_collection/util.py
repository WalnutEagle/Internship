import glob
import os
import sys
import numpy as np
import random

try:
    sys.path.append(glob.glob('../carla/dist/carla-*%d.%d-%s.egg' % (
        sys.version_info.major,
        sys.version_info.minor,
        'win-amd64' if os.name == 'nt' else 'linux-x86_64'))[0])
except IndexError:
    pass

try:
    import queue
except ImportError:
    import Queue as queue


import carla

from libcarla.command import SpawnActor as SpawnActor
from libcarla.command import SetAutopilot as SetAutopilot
from libcarla.command import SetVehicleLightState as SetVehicleLightState
from libcarla.command import FutureActor as FutureActor

WEATHER = {'ClearNoon':carla.WeatherParameters.ClearNoon,
    'ClearSunset': carla.WeatherParameters.ClearSunset,
    'WetNoon': carla.WeatherParameters.WetNoon,
    'HardRainNoon': carla.WeatherParameters.HardRainNoon,
    'WetCloudyNoon': carla.WeatherParameters.WetCloudyNoon,
    'SoftRainSunset': carla.WeatherParameters.SoftRainSunset,
    'HardRainSunset': carla.WeatherParameters.HardRainSunset}


def get_image(image, _type=None):
    if _type == 'semantic_segmentation':
        image.convert(carla.ColorConverter.CityScapesPalette)

    _array = np.frombuffer(image.raw_data, dtype=np.dtype("uint8"))
    _array = np.reshape(_array, (image.height, image.width, 4))
    _array = _array[:, :, :3]
    _array = _array[:, :, ::-1]

    if _type == 'depth':
        depth = np.float32(_array)
        normalized = (depth[:,:,0] + depth[:,:,1]*256 + depth[:,:,2]*256*256) / (256 * 256 * 256 - 1)
        in_meters = 1000 * normalized
        return in_meters
    else:
        return _array



def get_traffic_manager(client, port=4500):
    tm = client.get_trafficmanager(port)
    tm.set_global_distance_to_leading_vehicle(1.0)
    # tm.set_hybrid_physics_mode(True)
    tm.set_synchronous_mode(True)
    return tm


# -----------------
# Spawn vehicles
# -----------------


def spawn_vehicles(client, world, N, traffic_manager, vehicles_list):
    spawn_pts = world.get_map().get_spawn_points()
    vehicles_bp = world.get_blueprint_library().filter('vehicle.*')
    if len(spawn_pts) < N:
        print("vehicle spawn_pts < N")
        return False

    batch = []
    for idx in range(N):
        bp = random.choice(vehicles_bp)
        if bp.has_attribute('color'):
            color = random.choice(bp.get_attribute('color').recommended_values)
            bp.set_attribute('color', color)
        if bp.has_attribute('driver_id'):
            driver_id = random.choice(bp.get_attribute('driver_id').recommended_values)
            bp.set_attribute('driver_id', driver_id)
        bp.set_attribute('role_name', 'autopilot')

        batch.append(SpawnActor(bp, spawn_pts[idx])
                     .then(SetAutopilot(FutureActor, True, traffic_manager.get_port())))

    for response in client.apply_batch_sync(batch, True):  # True is for synchronize mode?
        if response.error:
            print(response.error)
        else:
            vehicles_list.append(response.actor_id)
    return True

# -----------------
# Spawn walkers
# -----------------


def spawn_walkers(client, world, N, percent_disabled, percent_walking, percent_crossing, all_id_dict):
    spawn_pts = []
    for i in range(N):
        spawn_pt = carla.Transform()
        random_loc = world.get_random_location_from_navigation()
        if random_loc != None:
            spawn_pt.location = random_loc
            spawn_pts.append(spawn_pt)
    print('walker spawn pts: ', len(spawn_pts))

    batch = []
    walkers_list = []
    walker_speed = []
    for pt in spawn_pts:
        walker_bp = random.choice(world.get_blueprint_library().filter('walker'))

        if walker_bp.has_attribute('is_invincible'):
            walker_bp.set_attribute('is_invincible', 'false')
        if walker_bp.has_attribute('speed'):
            if (random.random() < percent_walking):
                walker_speed.append(walker_bp.get_attribute('speed').recommended_values[1])
            else:
                walker_speed.append(walker_bp.get_attribute('speed').recommended_values[2])
        else:
            print("Walker has no speed")
            walker_speed.append(0.0)
        batch.append(SpawnActor(walker_bp, pt))
    
    for response in client.apply_batch_sync(batch, True):
        if response.error:
            print(response.error)
        else:
            walkers_list.append(response.actor_id)

    batch = []
    controller_list = []
    controller_bp = world.get_blueprint_library().find('controller.ai.walker')
    for walker in walkers_list:
        batch.append(SpawnActor(controller_bp, carla.Transform(), walker))
    for response in client.apply_batch_sync(batch, True):
        if response.error:
            print(response.error)
        else:
            controller_list.append(response.actor_id)

    all_id_dict.update({'walkers': walkers_list})
    all_id_dict.update({'controllers': controller_list})

    world.tick()

    world.set_pedestrians_cross_factor(percent_crossing)
    for id in controller_list:
        controller = world.get_actor(id)
        controller.start()
        controller.go_to_location(world.get_random_location_from_navigation())
        # all_actors[i].set_max_speed(float(walker_speed[int(i/2)]))

    # for walker in walkers_list:
    #     print(world.get_actor(walker).get_velocity())
    return True


# -----------------
# Spawn vehicles
# -----------------


def spawn_vehicles_new(client, world, number_of_vehicles, synchronous_master, traffic_manager, car_lights_on=False):
    two_veh_percent = 0.5
    vehicles_list = []
    spawn_points = world.get_map().get_spawn_points()
    batch = []
    vehicles_bp = world.get_blueprint_library().filter('vehicle.*')
    vehicles_bp_4 = [x for x in vehicles_bp if int(x.get_attribute('number_of_wheels')) == 4] # only use 4 wheel vehicles
    vehicles_bp_2 = [x for x in vehicles_bp if int(x.get_attribute('number_of_wheels')) == 2] # only use 2 wheel vehicles
    # hero = args.hero
    for n, transform in enumerate(spawn_points):
        if n >= number_of_vehicles:
            break
        if random.random() > two_veh_percent:
            blueprint = random.choice(vehicles_bp_4)
        else:
            blueprint = random.choice(vehicles_bp_2)

        if blueprint.has_attribute('color'):
            color = random.choice(blueprint.get_attribute('color').recommended_values)
            blueprint.set_attribute('color', color)
        if blueprint.has_attribute('driver_id'):
            driver_id = random.choice(blueprint.get_attribute('driver_id').recommended_values)
            blueprint.set_attribute('driver_id', driver_id)
        blueprint.set_attribute('role_name', 'autopilot')

        # spawn the cars and set their autopilot and light state all together
        batch.append(SpawnActor(blueprint, transform)
            .then(SetAutopilot(FutureActor, True, traffic_manager.get_port())))

    for response in client.apply_batch_sync(batch, synchronous_master):
        if response.error:
            print(response.error)
        else:
            vehicles_list.append(response.actor_id)

    # Set automatic vehicle lights update if specified
    if car_lights_on:
        all_vehicle_actors = world.get_actors(vehicles_list)
        for actor in all_vehicle_actors:
            traffic_manager.update_vehicle_lights(actor, True)

    return vehicles_list
# -----------------
# Spawn walkers
# -----------------

def spawn_walkers_new(client, world, number_of_walkers, seedw, percentagePedestriansRunning=0.1, percentagePedestriansCrossing=0.1):
    SpawnActor = carla.command.SpawnActor

    walkers_list = []
    all_id = []

    # # some settings
    # percentagePedestriansRunning = 0.1      # how many pedestrians will run
    # percentagePedestriansCrossing = 0.1     # how many pedestrians will walk through the road
    random.seed(seedw)

    nondisabledped_ids = ['%04d'%i for i in range(1,49+1)]

    visuallyimpairedped_ids = ['%04d'%i for i in range(50, 84+1)]

    wheelchairped_ids = ['%04d'%i for i in range(85, 160+1)]

    # 1. take all the random locations to spawn
    spawn_points = []
    # for i in range(number_of_walkers):
    while len(spawn_points) < number_of_walkers:
        spawn_point = carla.Transform()
        loc = world.get_random_location_from_navigation()
        if loc.z > 5: # resample if z > 5 meter
            continue

        if (loc != None):
            spawn_point.location = loc
            spawn_points.append(spawn_point)
    # 2. we spawn the walker object
    batch = []
    walker_speed = []
    for spawn_point in spawn_points:
        walker_bp = random.choice(world.get_blueprint_library().filter('walker.pedestrian.*'))
        if_disabled = False
        # set as not invincible
        if walker_bp.has_attribute('is_invincible'):
            walker_bp.set_attribute('is_invincible', 'false')
        # set the max speed
        if walker_bp.has_attribute('speed'):
            if if_disabled:
                # walking
                walker_speed.append(walker_bp.get_attribute('speed').recommended_values[1])
            elif (random.random() > percentagePedestriansRunning):
                # walking
                walker_speed.append(walker_bp.get_attribute('speed').recommended_values[1])
            else:
                # running
                walker_speed.append(walker_bp.get_attribute('speed').recommended_values[2])
        else:
            print("Walker has no speed")
            walker_speed.append(0.0)
        batch.append(SpawnActor(walker_bp, spawn_point))
    results = client.apply_batch_sync(batch, True)
    walker_speed2 = []
    for i in range(len(results)):
        if results[i].error:
            print(results[i].error)
        else:
            walkers_list.append({"id": results[i].actor_id})
            walker_speed2.append(walker_speed[i])
    walker_speed = walker_speed2
    # 3. we spawn the walker controller
    batch = []
    walker_controller_bp = world.get_blueprint_library().find('controller.ai.walker')
    for i in range(len(walkers_list)):
        batch.append(SpawnActor(walker_controller_bp, carla.Transform(), walkers_list[i]["id"]))
    results = client.apply_batch_sync(batch, True)
    for i in range(len(results)):
        if results[i].error:
            print(results[i].error)
        else:
            walkers_list[i]["con"] = results[i].actor_id
    # 4. we put together the walkers and controllers id to get the objects from their id
    for i in range(len(walkers_list)):
        all_id.append(walkers_list[i]["con"])
        all_id.append(walkers_list[i]["id"])
    all_actors = world.get_actors(all_id)

    # # wait for a tick to ensure client receives the last transform of the walkers we have just created
    # if args.asynch or not synchronous_master:
    #     world.wait_for_tick()
    # else:
    #     world.tick()
    world.tick()

    # 5. initialize each controller and set target to walk to (list is [controler, actor, controller, actor ...])
    # set how many pedestrians can cross the road
    world.set_pedestrians_cross_factor(percentagePedestriansCrossing)
    for i in range(0, len(all_id), 2):
        # start walker
        all_actors[i].start()
        # set walk to random point
        all_actors[i].go_to_location(world.get_random_location_from_navigation())
        # max speed
        all_actors[i].set_max_speed(float(walker_speed[int(i/2)]))

    return walkers_list, all_id