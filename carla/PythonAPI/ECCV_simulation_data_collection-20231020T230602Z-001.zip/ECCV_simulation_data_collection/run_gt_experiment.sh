#!/bin/bash

python run_gt_experiment.py --filter walker --world Town05 --path ./Town05_paths/path_points_t05_7_100_1.npy \
                            --start_id 7 --destination_id 100 --save_dir /home/tzm/Projects/2_Lab/carla_910/PythonAPI/image_captured \
                            --log_dir /home/tzm/Projects/2_Lab/carla_910/PythonAPI/vi_experiment_env/logs/
