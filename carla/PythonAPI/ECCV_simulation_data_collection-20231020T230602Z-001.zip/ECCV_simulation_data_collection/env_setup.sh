unset CARLA_ROOT
unset PYTHONPATH
unset PYTHONPATH
# for carla 9.10.1
export CARLA_ROOT=/data2/zanming/CARLA09101
export PYTHONPATH=$PYTHONPATH:$CARLA_ROOT/PythonAPI/carla
export PYTHONPATH=$PYTHONPATH:$CARLA_ROOT/PythonAPI/carla/dist/carla-0.9.10-py3.7-linux-x86_64.egg

